function basicImage(){
     let baseImage = cv.imread(document.getElementById('image1'));
     let dst = baseImage.clone();

     cv.cvtColor(baseImage, baseImage, cv.COLOR_RGBA2GRAY, 0);
     cv.threshold(baseImage, baseImage, 120, 200, cv.THRESH_BINARY);
     let contours = new cv.MatVector();
     let hierarchy = new cv.Mat();
     let rectangleColor = new cv.Scalar(255, 0, 0, 255);

     //cv.findContours(baseImage, contours, hierarchy, cv.RETR_CCOMP, cv.CHAIN_APPROX_SIMPLE);
     cv.findContours(baseImage, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);

     for (let i = 0; i < contours.size(); ++i) {
        let cnt = contours.get(i);
        let rect = cv.boundingRect(cnt);
        //cv.drawContours(dst, contours, i, contoursColor, 1, 8, hierarchy, 100);
        let point1 = new cv.Point(rect.x, rect.y);
        let point2 = new cv.Point(rect.x + rect.width, rect.y + rect.height);
        cv.rectangle(dst, point1, point2, rectangleColor, 2, cv.LINE_AA, 0);
     }
     cv.imshow('imageCanvas', dst);
     baseImage.delete();
     contours.delete();
     hierarchy.delete();
}

function sortContours(contours){
    //additional step: sort contours
    let sortableContours = [];
    for (let i = 0; i < contours.size(); i++) {
      let cnt = contours.get(i);
      //let area = cv.contourArea(cnt, false);
      let tenPercentArc = new cv.Mat();
      cv.approxPolyDP(cnt, tenPercentArc, 0.5 * cv.arcLength(cnt, true), true);
      let tenPercentLength = tenPercentArc.intAt(0,0)

      let onePercentArc = new cv.Mat();
      cv.approxPolyDP(cnt, onePercentArc, cv.arcLength(cnt, true), true);
      let onePercentLength = onePercentArc.intAt(0,0)

      sortableContours.push({ areaSize: Math.abs(onePercentLength - tenPercentLength), contour: cnt });
      tenPercentArc.delete();
      onePercentArc.delete();
    }

    //Sort 'em
    sortableContours = sortableContours.sort((item1, item2) => { return item1.areaSize - item2.areaSize });
    return sortableContours;
}

function getClosedContours(contours, hierarchy){

   let temp = new cv.MatVector();
    for( let i = 0; i< contours.size(); i=hierarchy.intAt(i, 0) ) // iterate through each contour.
    {
        if(hierarchy.intAt(i, 2)<0)
          temp.push_back(contours.get(i));
    }
    console.log("closed contours = "+temp.size())
    return temp;
}

function imageTest(){
    let src = cv.imread(document.getElementById('image1'));
    let gray = new cv.Mat();
    let contours = new cv.MatVector();
    let hierarchy = new cv.Mat();
    let rectangleColor = new cv.Scalar(0,255, 0, 255);
    let ksize = new cv.Size(5, 5);
    let M = cv.Mat.ones(5, 5, cv.CV_8U);
    let anchor = new cv.Point(-1, -1);

    //step2: convert to grayscale
    cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY, 0);

    //step3: blur it to reduce noise
    cv.GaussianBlur(gray, gray, ksize, 0, 0, cv.BORDER_DEFAULT );

    //step4: canny operation
    cv.Canny(gray, gray, 75, 200);

    //step4: apply threshold
    //cv.threshold(gray, gray, 0, 255, cv.THRESH_BINARY | cv.THRESH_OTSU);
    //cv.dilate(gray, gray, M, anchor, 1);

    //step5: get contours
    cv.findContours(gray, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);

    //sort them
    let sortableContours = sortContours(contours);

    //step6: go through top 5 sorted contours
    let count = 1;
    for (let i = 0; i < sortableContours.length && count<500; ++i) {
        let cnt = sortableContours[i].contour;

        let approx = new cv.Mat();
        let perimeter = cv.arcLength(cnt, true);
        cv.approxPolyDP(cnt, approx, 0.03 * perimeter, true);

        //let rect = cv.boundingRect(cnt);
        //let aspectRatio = rect.width/rect.height
        if(approx.rows > 6 ) {
            count++
            let temp = new cv.MatVector();
            temp.push_back(cnt);
            cv.drawContours(src, temp, 0, rectangleColor, 3, 8, hierarchy, 0);
            //cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)
            //streaming = false;
            temp.delete();
            //break;
            cv.imshow('imageCanvas', src);
        }
        approx.delete();
    }


    cv.imshow('imageThres', gray);

    src.delete();
    gray.delete();
    hierarchy.delete();
}

function videoSource() {
    streaming = true;
    video = document.getElementById('videoInput');
    let src = new cv.Mat(video.height, video.width, cv.CV_8UC4);
    let gray = new cv.Mat();
    let approx = new cv.Mat();
    let begin = Date.now();
    let contours = new cv.MatVector();
    let hierarchy = new cv.Mat();
    let rectangleColor = new cv.Scalar(0,255, 0, 255);
    let ksize = new cv.Size(5, 5);
    let M = cv.Mat.ones(5, 5, cv.CV_8U);
    let anchor = new cv.Point(-1, -1);

    function processVideo() {
        try {

            if (!streaming) {
                // clean and stop.
                src.delete();
                gray.delete();
                approx.delete();
                hierarchy.delete();
                return;
            }

            // step1: read source image
            cap.read(src);

            //step2: convert to grayscale
            cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY, 0);

            //step3: blur it to reduce noise
            cv.GaussianBlur(gray, gray, ksize, 0, 0, cv.BORDER_DEFAULT );

            //step4: canny operation
            cv.Canny(gray, gray, 75, 200);

            //step4: apply threshold
            //cv.threshold(gray, gray, 0, 255, cv.THRESH_BINARY | cv.THRESH_OTSU);
            cv.dilate(gray, gray, M, anchor, 1);

            //step5: get contours
            cv.findContours(gray, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_NONE);

            //additional step: sort contours
            let sortableContours = [];
            for (let i = 0; i < contours.size(); i++) {
              let cnt = contours.get(i);
              let area = cv.contourArea(cnt, false);
              sortableContours.push({ areaSize: area, contour: cnt });
            }

            //Sort 'em
            sortableContours = sortableContours.sort((item1, item2) => { return item2.areaSize - item1.areaSize }).slice(0, 5);


            //step6: go through top 5 sorted contours
            for (let i = 0; i < sortableContours.length; ++i) {
                let cnt = sortableContours[i].contour;

                let perimeter = cv.arcLength(cnt, true);
                cv.approxPolyDP(cnt, approx, 0.04 * perimeter, true);

                let rect = cv.boundingRect(cnt);
                let aspectRatio = rect.width/rect.height
                if(approx.rows == 4 && aspectRatio >=1.5 && aspectRatio <=1.6) {
                    let temp = new cv.MatVector();
                    temp.push_back(cnt);
                    cv.drawContours(src, temp, 0, rectangleColor, 3, 8, hierarchy, 0);
                    //cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    //streaming = false;
                    temp.delete();
                    //break;
                }
            }

            cv.imshow('imageCanvas', src);
            cv.imshow('imageThres', gray);


            // schedule the next one.
            let delay = 1000/FPS - (Date.now() - begin);
            setTimeout(processVideo, delay);
        } catch (err) {
            console.log(err);
        }
    }

    if (navigator.mediaDevices.getUserMedia) {
         navigator.mediaDevices.getUserMedia({video: { facingMode: { exact: "environment" } }})
        .then(function(stream) {
           video.srcObject = stream;
           cap = new cv.VideoCapture(video);
            // schedule the first one.
           setTimeout(processVideo, 0);
        })
        .catch(function(error) {
          console.log("Something went wrong!");
        });
    }
}
var cap, video, streaming = false;
const FPS = 30;
function stopVideo(){
    streaming = false;
}
